# Contributing
- Use Issues/PR templates.
- Follow Conventional Commits if possible.
- Run `npm run typecheck && npm run lint && npm test` before pushing.
