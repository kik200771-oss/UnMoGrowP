# ADR-0001: Migrate Frontend to Svelte 5
Decision: adopt Svelte 5 runes (`$state`, `$derived`, `$effect`), align components, remove mixed Svelte4/5 patterns.
