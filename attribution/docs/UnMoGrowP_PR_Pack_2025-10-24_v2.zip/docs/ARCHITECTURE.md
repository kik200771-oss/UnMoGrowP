# Architecture Overview
- Frontend: Svelte 5
- Backend: Go APIs
- Contracts: OpenAPI 3.1 (HTTP), JSON Schema (events)
