// Svelte 5 runes-based store example (pseudo; adapt to app runtime)
export function createAppState() {
  let state = { ready: false };
  function setReady(v: boolean) { state.ready = v; }
  return { state, setReady };
}
