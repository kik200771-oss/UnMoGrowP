export async function api(path: string, init: RequestInit = {}) {
  const base = import.meta.env.VITE_API_BASE_URL || '';
  const res = await fetch(base + path, {
    ...init,
    headers: { 'content-type': 'application/json', ...(init.headers || {}) }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
