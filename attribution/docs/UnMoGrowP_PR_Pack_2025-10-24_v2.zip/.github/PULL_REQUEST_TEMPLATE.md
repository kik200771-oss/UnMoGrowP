## Summary
Brief description.

## Checklist
- [ ] Linked issue(s)
- [ ] Unit tests (Vitest) updated
- [ ] E2E tests (Playwright) updated
- [ ] Types OK (`npm run typecheck`)
- [ ] Lint OK (`npm run lint`)
- [ ] Docs updated (README/ADR/OpenAPI/Schemas)
