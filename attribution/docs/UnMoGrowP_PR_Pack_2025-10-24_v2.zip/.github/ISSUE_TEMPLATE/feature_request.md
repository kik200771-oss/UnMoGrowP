---
name: Feature request
about: Propose an improvement
labels: enhancement
---

**Problem/Opportunity**
**Proposed solution**
**Acceptance criteria**
**Risks/Trade-offs**
