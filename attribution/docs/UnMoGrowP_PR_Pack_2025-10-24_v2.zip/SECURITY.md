# Security Policy
- Report vulnerabilities via Issues labeled `security` or email the maintainer.
- Secrets must not be committed. CI runs `gitleaks` on pushes/PRs.
