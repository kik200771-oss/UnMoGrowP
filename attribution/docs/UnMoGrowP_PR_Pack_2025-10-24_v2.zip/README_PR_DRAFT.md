# PR Draft: Bootstrap & Hardening
- [ ] Add `.env` and use `.env.example`
- [ ] Ensure scripts: `typecheck`, `lint`, `test`, `build`, `preview`
- [ ] Hook Vitest/Playwright
- [ ] Wire OpenAPI & JSON Schemas
- [ ] Enable Actions & Dependabot; branch protection
